<body class="hold-transition login-page">
	<?php $this->view($html); ?>

	<?php $this->view('template/body_javascript'); ?>
</body>