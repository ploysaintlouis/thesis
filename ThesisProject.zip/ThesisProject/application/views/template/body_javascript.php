<!-- javascript -->
<?php echo js_asset('jquery-3.1.1.js'); ?>
<?php echo js_asset('jQuery-UI/jquery-ui.js'); ?>
<?php echo js_asset('bootstrap.min.js'); ?>
<?php echo js_asset('fastclick.js'); ?>
<?php echo js_asset('app.min.js'); ?>
<?php echo js_asset('demo.js'); ?>

<?php echo js_asset('common.js'); ?>
<?php echo js_asset('bootstrap-datetimepicker.js'); ?>
<?php echo js_asset('bootstrap-datepicker.js'); ?>
<?php echo js_asset('locales/bootstrap-datetimepicker.th.js'); ?>
<?php echo js_asset('select2.full.min.js'); ?>
<?php echo js_asset('iCheck/icheck.min.js'); ?>

<?php echo js_asset('mainControl.js'); ?>